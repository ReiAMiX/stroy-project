from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),

    path('categories/', views.category_list, name='category_list'),
    path('category/<int:category_id>/', views.product_list, name='product_list'),

    path('register/', views.register, name='register'),

    path('cart/', views.cart, name='cart'),
    path('cart/add/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('cart/decrease/<int:item_id>/', views.decrease_cart_item, name='decrease_cart_item'),
    path('cart/remove/<int:item_id>/', views.remove_from_cart, name='remove_from_cart'),

    path('search/', views.search, name='search'),
    path('product/<int:product_id>/', views.product_detail, name='product_detail'),
    path('product/<int:product_id>/review/', views.add_review, name='add_review'),
    path('favorite/<int:product_id>/', views.toggle_favorite, name='toggle_favorite'),
]

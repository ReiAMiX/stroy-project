from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth import login

from .models import Category, Product, CartItem, Review, Favorite


def home(request):
    categories = Category.objects.all()
    return render(request, 'shop/home.html', {'categories': categories})


def category_list(request):
    categories = Category.objects.all()
    return render(request, 'shop/category_list.html', {'categories': categories})


def product_list(request, category_id):
    category = get_object_or_404(Category, id=category_id)
    products = Product.objects.filter(category=category)
    return render(request, 'shop/product_list.html', {
        'category': category,
        'products': products
    })


def product_detail(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    reviews = Review.objects.filter(product=product)
    return render(request, 'shop/product_detail.html', {
        'product': product,
        'reviews': reviews
    })


@login_required
def cart(request):
    items = CartItem.objects.filter(user=request.user)
    return render(request, 'shop/cart.html', {'items': items})


@login_required
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    item, created = CartItem.objects.get_or_create(
        user=request.user,
        product=product
    )
    if not created:
        item.quantity += 1
        item.save()
    return redirect('cart')


@login_required
def decrease_cart_item(request, item_id):
    item = get_object_or_404(CartItem, id=item_id, user=request.user)
    if item.quantity > 1:
        item.quantity -= 1
        item.save()
    else:
        item.delete()
    return redirect('cart')


@login_required
def remove_from_cart(request, item_id):
    item = get_object_or_404(CartItem, id=item_id, user=request.user)
    item.delete()
    return redirect('cart')


def search(request):
    query = request.GET.get('q', '')
    products = Product.objects.filter(name__icontains=query)
    return render(request, 'shop/search.html', {
        'products': products,
        'query': query
    })


@login_required
def add_review(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        text = request.POST.get('text')
        if text:
            Review.objects.create(
                user=request.user,
                product=product,
                text=text
            )
    return redirect('product_detail', product_id=product.id)


@login_required
def toggle_favorite(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    fav, created = Favorite.objects.get_or_create(
        user=request.user,
        product=product
    )
    if not created:
        fav.delete()
    return redirect(request.META.get('HTTP_REFERER', 'home'))


def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')
    else:
        form = UserCreationForm()

    return render(request, 'shop/register.html', {'form': form})
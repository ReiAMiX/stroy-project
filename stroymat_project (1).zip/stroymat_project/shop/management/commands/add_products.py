from django.core.management.base import BaseCommand
from shop.models import Category, Product

class Command(BaseCommand):
    help = "Добавляет тестовые товары с картинками и ценами в сумы"

    def handle(self, *args, **kwargs):
        cat1, _ = Category.objects.get_or_create(name="Сантехника")
        cat2, _ = Category.objects.get_or_create(name="Стройматериалы")
        cat3, _ = Category.objects.get_or_create(name="Инструменты")

        products = [
            {"category": cat1, "name": "Смеситель", "price": 2500*150,
             "description": "Качественный смеситель для кухни", "image": "products/faucet.jpg"},
            {"category": cat2, "name": "Цемент Knauf", "price": 500*150,
             "description": "Портландцемент Knauf 50 кг", "image": "products/cement_knauf.jpg"},
            {"category": cat3, "name": "Перфоратор", "price": 7500*150,
             "description": "Мощный перфоратор для стройки", "image": "products/drill.jpg"},
            {"category": cat2, "name": "Гипсокартон Knauf", "price": 3000*150,
             "description": "Лист гипсокартона Knauf стандарт", "image": "products/gypsum_knauf.jpg"},
            {"category": cat2, "name": "Кирпич", "price": 30*150,
             "description": "Красный строительный кирпич", "image": "products/brick.jpg"},
        ]

        for p in products:
            product, created = Product.objects.get_or_create(
                category=p["category"],
                name=p["name"],
                defaults={
                    "price": p["price"],
                    "description": p["description"],
                    "image": p["image"]
                }
            )

        self.stdout.write(self.style.SUCCESS("Товары с изображениями и ценами в сумах добавлены!"))